
# '======[Importaciones]============================'
from django.shortcuts import render, redirect, get_object_or_404
from django.http import HttpResponseRedirect
from django.urls import reverse
from django.core.paginator import Paginator # PAGINAS DINAMICAS
from django.db.models import Count, Avg # CONTADOR DE FILTROS Y AVG (promedio)
from django.templatetags.static import static

from django.contrib import messages # Importante para calificacion visual

from django.contrib.auth.decorators import login_required

# ----[MODELS & FORMS IMPORTS]-------------------
from Apps.Productos import models as ProductoModel
from Apps.Productos import forms as ProductoForm
# '================================================='

# °===========================°
#    °Vistas -> Productos
# °===========================°

# CONSTANTE DE LA LISTA DE IMAGENES PARA LAS CATEGORIA
CATEGORIA_IMAGENES = {
    'adaptadores': 'img/CategoriasVec/adaptadores.png',
    'altavoces': 'img/CategoriasVec/altavoces.png',
    'audifonos': 'img/CategoriasVec/audifonos.png',
    'computadoras': 'img/CategoriasVec/computadoras.png',
    'consolas': 'img/CategoriasVec/consolas.png',
    'impresoras': 'img/CategoriasVec/impresoras.png',
    'inalambricos': 'img/CategoriasVec/inalambricos.png',
    'mouse': 'img/CategoriasVec/mouse.png',
    'televisores': 'img/CategoriasVec/televisores.png',
    'teclados': 'img/CategoriasVec/teclados.png',
    'otros': 'img/CategoriasVec/box.png',
}


# ====== FUNCION AUXILIAR ======
def _procesar_imagenes(lista_productos):
    """
    Asigna la URL de la imagen de categoria a cada producto en la lista
    """
    for producto in lista_productos:
        # Obtenemos la primera relación de categoría
        relacion = ProductoModel.ProductoCategoria.objects.filter(producto_id=producto).first()
        
        if relacion:
            nombre_cat = relacion.categoria_id.nombre.lower()
            # Verificar si existe un imagen para la categoria capturada
            if nombre_cat in CATEGORIA_IMAGENES:
                producto.url_categoria = static(CATEGORIA_IMAGENES[nombre_cat])
            else:
                producto.url_categoria = None
            producto.nombre_categoria = relacion.categoria_id.nombre
        else:
            producto.url_categoria = None
            producto.nombre_categoria = "Otras"
    return lista_productos

# !|-|--|-|-|-|-|-|-|> VISTAS GENERALES <|-|-|-|-|-|-|-|-|-|-|-|-|-|-|-|-|-|-|-|
# Redireccion al HOME principal del proyecto
def homeGeneral(request):
    return render(request, 'index.html')


# !|-|--|-|-|-|-|-|-|> VISTAS DE PRODUCTOS <|-|-|-|-|-|-|-|-|-|-|-|-|-|-|-|-|-|-|-|

# .|----------------[MOSTRAR PRODUCTOS]----------------|.

# .|======== CATALOGO DE PRODUCTOS ==============>>
@login_required(login_url='/productos/home/') # <- DECORADOR que obliga a los usuarios a estar logeados
def catalogo_producto(request):

    productos_list = ProductoModel.Producto.objects.all().order_by('-fecha_registro')
    
    # --------||=--== FILTROS ==--=||--------
    # Buscar por ID
    busqueda_id = request.GET.get('busqueda_id')
    if busqueda_id:
        if busqueda_id.isdigit(): 
            productos_list = productos_list.filter(id=busqueda_id)
        else:
            productos_list = productos_list.none()

    # Buscar por NOMBRE
    busqueda_nombre = request.GET.get('busqueda_nombre')
    if busqueda_nombre:
        productos_list = productos_list.filter(nombre__icontains=busqueda_nombre)

    # Buscar por RANGOS de PRECIOS
    precio_min = request.GET.get('precio_min')
    if precio_min:
        productos_list = productos_list.filter(precio__gte=precio_min)

    precio_max = request.GET.get('precio_max')
    if precio_max:
        productos_list = productos_list.filter(precio__lte=precio_max)

    # Buscar por CARTEGORIAS
    categoria_id = request.GET.get('categoria')
    if categoria_id:
        productos_list = productos_list.filter(productocategoria__categoria_id=categoria_id)

    # ORGANIZACION POR PRECIO
    orden = request.GET.get('orden')
    if orden == 'precio_asc':
        productos_list = productos_list.order_by('precio')
    elif orden == 'precio_desc':
        productos_list = productos_list.order_by('-precio')

    # PAGINACION
    paginas = Paginator(productos_list, 12)
    num_pagina = request.GET.get('page')
    paginasObject = paginas.get_page(num_pagina)


    # --||=--== CLASIFICAION de IMAGENES por NOMBRES ==--=||--------
    for producto in paginasObject:
        relacion = ProductoModel.ProductoCategoria.objects.filter(producto_id=producto.id).first()
        
        if relacion:
            nombre_cat = relacion.categoria_id.nombre
            producto.nombre_categoria = nombre_cat
            
            key_lower = nombre_cat.lower()
            # Validacion de que el diccionario exista y tenga la clave
            if 'CATEGORIA_IMAGENES' in globals() and key_lower in CATEGORIA_IMAGENES:
                 producto.url_categoria = static(CATEGORIA_IMAGENES[key_lower])
            else:
                 producto.url_categoria = None 
        else:
            producto.nombre_categoria = "General"
            producto.url_categoria = None

    # Datos de la SideBar
    categorias = ProductoModel.Categoria.objects.annotate(contador_productos=Count('productocategoria'))

    # MANTENER PARAMETROS EN URL
    params = request.GET.copy()
    if 'page' in params: 
        del params['page']
    base_params = params.urlencode()

    data = {
        'productoKey': paginasObject,
        'ultimos_productos': paginasObject,
        'categoriasKey': categorias,
        'base_params': base_params,
    }
    return render(request, 'Producto/catalogo_producto.html', data)


# .|======== DETALLE DE UN PRODUCTO ==============>>
@login_required(login_url='/productos/home/')
# def detalle_producto(request, id_producto):
#     # OBTIENE EL OBJETO O SI NO UN ERROR 404 (dos en uno)
#     producto = get_object_or_404(ProductoModel.Producto, id=id_producto)
    
#     # Calcular promedio de estrellas
#     promedio_calificacion = producto.calificaciones.aggregate(Avg('cant_estrella'))['cant_estrella__avg']
    
#     # Formularios vacios para la vista
#     form_comentario = ProductoForm.RegisterComentarioForm()
#     form_calificacion = ProductoForm.RegisterCalificacionForm()

#     # --- Logica para obtener la URL de la imagen (filtrado por producto_id) ---
#     relacion = ProductoModel.ProductoCategoria.objects.filter(producto_id=producto).first() 
    
#     if relacion:
#         nombre_cat = relacion.categoria_id.nombre.lower()
#         # SE USA EL DICCIONARIO DE IMAGENES ↓↓ definido arriba
#         producto.url_categoria = static(CATEGORIA_IMAGENES.get(nombre_cat)) if nombre_cat in CATEGORIA_IMAGENES else None
#         producto.nombre_categoria = relacion.categoria_id.nombre
#     else:
#         producto.url_categoria = None
#         producto.nombre_categoria = "Otros"
#     # --- FIN Logica para obtener la URL de la imagen ---

#     data = {
#         'producto': producto,
#         'promedio_calificacion': promedio_calificacion,
#         'formComentario': form_comentario,
#         'formCalificacion': form_calificacion,
#         'comentariosKey': producto.comentarios.all().order_by('-fecha_registro'), 
#     }
#     return render(request, 'Producto/detalle_producto.html', data)




@login_required(login_url='/productos/home/')
def detalle_producto(request, id_producto):
    producto = get_object_or_404(ProductoModel.Producto, id=id_producto)
    
    # 1. Calcular promedio (igual que antes)
    promedio_calificacion = producto.calificaciones.aggregate(Avg('cant_estrella'))['cant_estrella__avg']
    
    # 2. Obtener todos los comentarios del producto
    comentarios_db = producto.comentarios.all().select_related('cliente').order_by('-fecha_registro')
    
    # 3. LÓGICA NUEVA: Unir Comentario + Calificación
    lista_opiniones = []
    
    for coment in comentarios_db:
        # Buscamos si este cliente tiene una calificación para este producto
        calificacion = ProductoModel.Calificacion.objects.filter(
            producto=producto, 
            cliente=coment.cliente
        ).first()
        
        # Obtenemos el número de estrellas (0 si no calificó)
        num_estrellas = calificacion.cant_estrella if calificacion else 0
        
        # Creamos un diccionario con toda la info lista para el HTML
        opinion = {
            'cliente': coment.cliente,          # El objeto usuario
            'texto': coment.comentario,         # El texto
            'fecha': coment.fecha_registro,     # La fecha
            'estrellas': num_estrellas,         # Número entero (ej: 5)
            'rango_llenas': range(num_estrellas),           # Para el loop de estrellas amarillas
            'rango_vacias': range(5 - num_estrellas)        # Para el loop de estrellas grises
        }
        lista_opiniones.append(opinion)

    # ... (Tu lógica de imágenes sigue igual aquí) ...
    relacion = ProductoModel.ProductoCategoria.objects.filter(producto_id=producto).first()
    if relacion:
        nombre_cat = relacion.categoria_id.nombre.lower()
        producto.url_categoria = static(CATEGORIA_IMAGENES.get(nombre_cat)) if nombre_cat in CATEGORIA_IMAGENES else None
        producto.nombre_categoria = relacion.categoria_id.nombre
    else:
        producto.url_categoria = None
        producto.nombre_categoria = "Otros"

    form_comentario = ProductoForm.RegisterComentarioForm()
    form_calificacion = ProductoForm.RegisterCalificacionForm()

    data = {
        'producto': producto,
        'promedio_calificacion': promedio_calificacion,
        'formComentario': form_comentario,
        'formCalificacion': form_calificacion,
        'lista_opiniones': lista_opiniones, # <--- ENVIAMOS LA NUEVA LISTA PROCESADA
    }
    return render(request, 'Producto/detalle_producto.html', data)


# .|----------------[AGREGAR CALIFICACION (ESTRELLAS + COMENTARIO)]----------------|.
@login_required(login_url='/productos/home/')
# def agregar_calificacion(request, id_producto):

#     producto = get_object_or_404(ProductoModel.Producto, id=id_producto)
    
#     if request.method == 'POST':

#         form_comentario = ProductoForm.RegisterComentarioForm(request.POST)
#         form_estrellas = ProductoForm.RegisterCalificacionForm(request.POST)
        
#         try:
#             # Guardar Comentario (solo si el user escribio algo)
#             if form_comentario.is_valid():
#                 comentario_texto = request.POST.get('comentario', '').strip()
#                 if comentario_texto:
#                     comentario = form_estrellas.save(commit=False)
#                     comentario.cliente = request.user
#                     comentario.producto = producto
#                     comentario.save()

#             # Guardar Calificación (Estrellas)
#             if form_estrellas.is_valid():
#                 calificacion = form_estrellas.save(commit=False)
#                 calificacion.cliente = request.user
#                 calificacion.producto = producto
#                 calificacion.save()
#             else:

#                 estrellas = request.POST.get('cant_estrella')
#                 if estrellas:
#                     ProductoModel.Calificacion.objects.create(producto=producto, cliente=request.user, cant_estrella=int(estrellas))
            
#             messages.success(request, '¡Gracias por tu calificacion!')
            
#         except Exception as err:
#             messages.error(request, f'Error al guardar tu opinión: {err}')
            
#     return HttpResponseRedirect(reverse('detalleProducto', args=[id_producto]))


def agregar_calificacion(request, id_producto):
    producto = get_object_or_404(ProductoModel.Producto, id=id_producto)
    
    if request.method == 'POST':
        # Instanciamos el formulario del comentario
        form_comentario = ProductoForm.RegisterComentarioForm(request.POST)
        
        try:
            # 1. PROCESAR COMENTARIO
            # Verificamos si el formulario es válido y si enviaron texto
            if form_comentario.is_valid():
                # Obtenemos el texto limpio
                texto = form_comentario.cleaned_data.get('comentario', '').strip()
                
                if texto:
                    # CORRECCIÓN: Usamos form_comentario, NO form_estrellas
                    nuevo_comentario = form_comentario.save(commit=False)
                    nuevo_comentario.cliente = request.user
                    nuevo_comentario.producto = producto
                    nuevo_comentario.save()

            # 2. PROCESAR ESTRELLAS (CALIFICACIÓN)
            # Como usas radio buttons manuales en el HTML, es más seguro capturarlos directo del POST
            estrellas = request.POST.get('cant_estrella')
            
            if estrellas:
                # Opcional: Verificar si ya calificó para actualizar en vez de crear una nueva
                # (Aquí usamos update_or_create para que un usuario no tenga 10 calificaciones del mismo producto)
                ProductoModel.Calificacion.objects.update_or_create(
                    producto=producto,
                    cliente=request.user,
                    defaults={'cant_estrella': int(estrellas)}
                )

            messages.success(request, '¡Gracias por tu opinión!')
            
        except Exception as err:
            messages.error(request, f'Ocurrió un error al guardar: {err}')
            
    return HttpResponseRedirect(reverse('detalleProducto', args=[id_producto]))


# .|----------------[REGISTRAR PRODUCTO]----------------|.
@login_required(login_url='/productos/home/')
def registrar_producto(request):
    formProducto = ProductoForm.RegisterProductoForm() 
    
    if request.method == 'POST':
        formProducto = ProductoForm.RegisterProductoForm(request.POST)
        if formProducto.is_valid():
            # Guardar Producto
            producto_instance = formProducto.save(commit=False)
            
            # ASIGNACIÓN DEL ADMIN
            producto_instance.admin = request.user 
            producto_instance.save()
            
            # RELACION MANY TO MANY (Categoria)
            categorias_seleccionadas = formProducto.cleaned_data.get('categoria_id')
            
            # LIMPIEZA DE REFERENCIAS Y CREACION DE NUEVAS (for .. in)
            ProductoModel.ProductoCategoria.objects.filter(producto_id=producto_instance).delete()
            
            for categoria in categorias_seleccionadas:
                 ProductoModel.ProductoCategoria.objects.create(
                     producto_id=producto_instance, 
                     categoria_id=categoria
                 )
            
            return HttpResponseRedirect(reverse('catalogoProductos'))
    
    # MOSTRAR LOS ULTIMOS 5 PRODUCTOS REGISTRADO orden fecha desasendente
    ultimos_productos = ProductoModel.Producto.objects.all().order_by('-fecha_registro')[:5]
    _procesar_imagenes(ultimos_productos)

    data = {
        'formKey': formProducto,
        'ultimos_productos': ultimos_productos,
    }
    return render(request, 'Producto/registrar_producto.html', data)


# .|----------------[EDITAR PRODUCTO]----------------|.
@login_required(login_url='/productos/home/')
def editar_producto(request, id_producto):

    # OBTIENE EL OBJETO O SI NO UN ERROR 404 (dos en uno)
    producto = get_object_or_404(ProductoModel.Producto, id=id_producto)
    
    if request.method == 'POST':
        form = ProductoForm.RegisterProductoForm(request.POST, instance=producto)
        if form.is_valid():
            producto_instance = form.save(commit=False)
            
            # Si el campo admin_id está vacío, se podría reasignar al usuario actual
            if not producto_instance.admin_id:
                producto_instance.admin_id = request.user
                
            producto_instance.save()
            
            # Actualizar Categorías
            categorias_seleccionadas = form.cleaned_data.get('categoria_id')
            ProductoModel.ProductoCategoria.objects.filter(producto_id=producto_instance).delete()
            
            for categoria in categorias_seleccionadas:
                ProductoModel.ProductoCategoria.objects.create(
                    producto_id=producto_instance, 
                    categoria_id=categoria
                )
            return HttpResponseRedirect(reverse('catalogoProductos'))
    else:
        # Pre-llenar el formulario con las categorías actuales
        ids_cats = ProductoModel.ProductoCategoria.objects.filter(producto_id=producto).values_list('categoria_id', flat=True)
        form = ProductoForm.RegisterProductoForm(instance=producto, initial={'categoria_id': ids_cats})

    data = {
        'formKey': form
    }
    return render(request, 'Producto/registrar_producto.html', data)


# .|----------------[ELIMINAR PRODUCTO]----------------|.
@login_required(login_url='/productos/home/')
def eliminar_producto(request, id_producto):

    # OBTIENE EL OBJETO O SI NO UN ERROR 404 (dos en uno)
    producto = get_object_or_404(ProductoModel.Producto, id=id_producto)
    producto.delete()
    return HttpResponseRedirect(reverse('catalogoProductos'))


# !|-|--|-|-|-|-|-|-|> VISTAS DE CATEGORIAS <|-|-|-|-|-|-|-|-|-|-|-|-|-|-|-|-|-|-|-|

# .|----------------[MOSTRAR CATEGORIAS]----------------|.
@login_required(login_url='/productos/home/')
def data_categoria(request):
    categoriaObject = ProductoModel.Categoria.objects.all()
    data = {
        'categoriaKey': categoriaObject,
        'mainTitle': 'Listado de categorías',
    }
    return render(request, 'ModerElectronic/data_Categoria.html', data)


# .|----------------[REGISTRAR CATEGORIAS]----------------|.
@login_required(login_url='/productos/home/')
def registrar_categoria(request):
    formCategoria = ProductoForm.RegisterCategoriaForm()
    
    if request.method == 'POST':
        formCategoria = ProductoForm.RegisterCategoriaForm(request.POST)
        if formCategoria.is_valid():
            formCategoria.save()
            return HttpResponseRedirect(reverse('registrarProducto')) 
    
    categorias_registradas = ProductoModel.Categoria.objects.all().order_by('nombre')
    
    data = {
        'formKey': formCategoria,
        'mainTitle': 'Registro de Categorias',
        'txtBtn': 'Guardar Categoria',
        'categorias_registradas': categorias_registradas,
    }
    return render(request, 'Producto/Extras/registrar_categoria.html', data)


# !|-|--|-|-|-|-|-|-|> VISTAS DE SOLICITUDES <|-|-|-|-|-|-|-|-|-|-|-|-|-|-|-|-|-|-|-|

# .|----------------[REGISTRAR SOLICITUD]----------------|.
@login_required(login_url='/productos/home/')
def register_Solicitud(request, id_producto):
    # OBTIENE EL OBJETO O SI NO UN ERROR 404 (dos en uno)
    producto = get_object_or_404(ProductoModel.Producto, id=id_producto)
    
    if request.method == 'POST':
        form_solicitud = ProductoForm.RegisterSolicitudForm(request.POST) 
        if form_solicitud.is_valid():
            solicitud = form_solicitud.save(commit=False)
            solicitud.producto_id = producto 
            solicitud.cliente_id = request.user
            solicitud.estado = True 
            solicitud.tipo_solicitud = 'en revision'
            solicitud.save()
            return HttpResponseRedirect(reverse('catalogoProductos'))
    else:
        form_solicitud = ProductoForm.RegisterSolicitudForm()
        
    data= {
        'formSolicitudKey': form_solicitud,
        'id_producto': id_producto
    }
    return render(request, 'Usuario/Solicitud/solicitud.html', data)


# .|----------------[MOSTRAR SOLICITUD]----------------|.
@login_required(login_url='/productos/home/')
def data_Solicitud(request):
    solicitudObject = ProductoModel.Solicitud.objects.all()
    data = {
        'solicitudKey': solicitudObject,
        'mainTitle': 'Registro de solicitudes',
    }
    return render(request, 'Usuario/Solicitud/data_solicitud.html', data)


# !|-|--|-|-|-|-|-|-|> VISTA DE COMPRA <|-|-|-|-|-|-|-|-|-|-|-|-|-|-|-|-|-|-|-|

# .|----------------[REGISTRAR COMPRA]----------------|.
@login_required(login_url='/productos/home/')
def comprar_producto(request, id_producto):
    producto = get_object_or_404(ProductoModel.Producto, id=id_producto)
    cliente = request.user

    if cliente.billetera >= producto.precio and producto.stock > 0:
        # Descontar saldo y stock
        cliente.billetera -= producto.precio
        cliente.save(update_fields=['billetera'])

        producto.stock -= 1
        producto.save(update_fields=['stock'])

        # Registrar compra
        ProductoModel.RegistroCompra.objects.create(
            cliente=cliente,
            producto=producto,
            precio_total=producto.precio,
            garantia=False,
            delivery=False
        )

        messages.success(request, f" Producto '{producto.nombre}' comprado con éxito. Nuevo saldo: ${cliente.billetera}")
    else:
        messages.error(request, " Compra cancelada. Verifique su saldo o stock del producto.")

    return redirect('catalogoProductos')



# '======[Importaciones]============================'
from django.urls import reverse_lazy

# IMPORTACION DE forms
from Apps.Usuarios import forms as UsuariosForms 
from Apps.Usuarios import models as UsuariosModels 
from Apps.Productos import models as ProductoModel

# Autenticación y vistas basadas en clases
from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth.views import LoginView
from django.views.generic import CreateView, DetailView, UpdateView, ListView

from django.contrib.auth.mixins import LoginRequiredMixin

from django.views.generic.edit import FormView
from django.contrib import messages
from django.views.generic import TemplateView
# '================================================='

# °===========================°
#    °Vistas -> Usuarios
# °===========================°

# !|-|--|-|-|-|-|-|-|> VISTA BASADAS EN CLASE PARA LA GESTION DE CLIENTES <|-|--|-|-|-|-|-|-|-|-|-|-|-

class CrearCuentaViewCliente(CreateView):
    form_class = UsuariosForms.ClienteSignUpForm # Formulario personalizado
    success_url = reverse_lazy("iniciarSesionCliente") # redireccionamiento 
    template_name = "Usuario/ingreso/crear_cuenta/crear_cliente.html" # ubicacion del template


class IniciarSesionViewCliente(LoginView):
    form_class = AuthenticationForm
    template_name = "usuario/ingreso/iniciar_sesion/iniciar_cliente.html"
    redirect_authenticated_user = False

# !|-|--|-|-|-|-|-|-|> VISTA BASADAS EN CLASE PARA LA GESTION DE ADMINISTRADORES <|-|--|-|-|-|-|-|-|-|-|-|-|-

class CrearCuentaViewAdmin(CreateView):
    form_class = UsuariosForms.AdminSignUpForm
    success_url = reverse_lazy("iniciarSesionAdmin")
    template_name = "Usuario/ingreso/crear_cuenta/crear_admin.html"

class IniciarSesionViewAdmin(LoginView):
    form_class = AuthenticationForm
    template_name = "usuario/ingreso/iniciar_sesion/iniciar_admin.html"
    redirect_authenticated_user = False


# !|-|--|-|-|-|-|-|-|> VISTA PARA MOSTRAR EL PERFIL <|-|--|-|-|-|-|-|-|-|-|-|-|-

class PerfilUsuarioDetailView(LoginRequiredMixin, DetailView):
    model = UsuariosModels.Usuario
    template_name = 'Usuario/Perfil/mostrar_perfil.html' # Crea este nuevo template
    context_object_name = 'usuario_perfil' # Nombre de la variable en el template

    # Esta función se asegura de que la vista siempre cargue el usuario logueado.
    def get_object(self, queryset=None):
        return self.request.user

# !|-|--|-|-|-|-|-|-|> VISTA PARA EDITAR EL PERFIL <|-|--|-|-|-|-|-|-|-|-|-|-|-

class PerfilUsuarioUpdateView(LoginRequiredMixin, UpdateView):
    model = UsuariosModels.Usuario
    form_class = UsuariosForms.PerfilUsuarioUpdateForm
    template_name = 'Usuario/Perfil/editar_perfil.html' # Crea este nuevo template
    success_url = reverse_lazy('perfilUsuario') # Redirección después de guardar

    # Esta función se asegura de que solo se edite el usuario logueado.
    def get_object(self, queryset=None):
        return self.request.user


# !|-|--|-|-|-|-|-|-|> VISTA PARA EDITAR EL PERFIL <|-|--|-|-|-|-|-|-|-|-|-|-|-

class SeleccionarMetodoRecargaView(LoginRequiredMixin, TemplateView):
    template_name = "Billetera/seleccionar_metodo.html"

class RecargarBilleteraView(LoginRequiredMixin, FormView):
    model = UsuariosModels.Usuario
    form_class = UsuariosForms.RecargaBilleteraForm
    template_name = "Billetera/recargar_billetera.html"
    success_url = reverse_lazy("confirmacionRecarga")

    def form_valid(self, form):
        monto = form.cleaned_data['monto']
        usuario = self.request.user
        usuario.billetera += monto
        usuario.save(update_fields=['billetera'])
        # guardamos el monto en sesión para mostrarlo en confirmación
        self.request.session['ultimo_monto'] = monto
        return super().form_valid(form)
    
class ConfirmacionRecargaView(LoginRequiredMixin, TemplateView):
    template_name = "Billetera/confimarcion_recarga.html"

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        ctx["usuario"] = self.request.user
        ctx["monto"] = self.request.session.get('ultimo_monto', 0)  # recupera el último monto recargado
        return ctx



class HistorialComprasView(LoginRequiredMixin, ListView):
   
    model = ProductoModel.RegistroCompra 
    template_name = 'Usuario/Perfil/historial_compras.html'
    context_object_name = 'registros_compra' 

    def get_queryset(self):
        
        return ProductoModel.RegistroCompra.objects.filter(
            cliente=self.request.user
        ).order_by('-fecha_compra')
    
    